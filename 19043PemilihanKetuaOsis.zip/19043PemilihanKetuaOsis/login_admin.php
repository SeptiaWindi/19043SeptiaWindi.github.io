
<div class="jumbotron">
     <center>
     <form action="aksi_admin.php" method="POST">
     	<table class="table">
        	<tr>
            	<td>nis</td>
                <td>:</td>
                <td><input type="text" name="admin_nis" required="required" class="form-control" /></td>
             </tr>
        	<tr>
            	<td>Password</td>
                <td>:</td>
                <td><input type="password" name="admin_password"  required="required" class="form-control" /></td>
             </tr>
        	<tr>
                <td colspan="3"><input type="submit" name="login_admin" class="btn btn-primary" value="Login admin" /></td>
             </tr>
        </table>
        </form>
     </center>
 </div> 