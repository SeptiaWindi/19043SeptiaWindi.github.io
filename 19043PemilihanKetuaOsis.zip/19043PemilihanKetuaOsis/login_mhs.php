 <div class="jumbotron">
     <center>
     <form action="aksi_mhs.php" method="POST">
     	<table class="table">
        	<tr>
            	<td>nis</td>
                <td>:</td>
                <td><input type="text" name="siswa_nis" required="required" class="form-control" /></td>
             </tr>
        	<tr>
            	<td>Password</td>
                <td>:</td>
                <td><input type="password" name="siswa_password"  required="required" class="form-control" /></td>
             </tr>
        	<tr>
                <td colspan="3"><input type="submit" name="login_mhs" class="btn btn-primary" value="Login siswa" /></td>
             </tr>
        </table>
        </form>
     </center>
 </div> 