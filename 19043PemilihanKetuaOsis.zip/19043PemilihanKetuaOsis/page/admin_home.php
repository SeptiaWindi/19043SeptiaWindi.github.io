 <div class="jumbotron">
            <h3>Selamat datang dihalaman admin,</h3>
            <p>Di Aplikasi e-Voting PILKETOS SMKN 1 BAWANG</p>
 </div> 